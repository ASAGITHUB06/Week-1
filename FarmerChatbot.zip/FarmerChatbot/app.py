from flask import Flask, request, jsonify, render_template
import requests
from datetime import datetime, timedelta
import random

app = Flask(__name__)

WEATHER_API_KEY = 'd639a2733b0ec4ecb094bb86c3affc3d'

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/weather', methods=['GET'])
def get_weather():
    city = request.args.get('city')
    url = f'https://api.openweathermap.org/data/2.5/weather?q={city}&appid={WEATHER_API_KEY}&units=metric'
    response = requests.get(url).json()
    if response.get('cod') != 200:
        return jsonify({'error': 'City not found'})
    weather = response['weather'][0]['description']
    temp = response['main']['temp']

    # Add basic weather advice
    if "rain" in weather:
        tip = "Rainy weather: Ensure fields have good drainage."
    elif "clear" in weather or "sunny" in weather:
        tip = "Clear weather: Good for harvesting and fieldwork."
    elif "cloud" in weather:
        tip = "Cloudy weather: Monitor for potential rainfall."
    else:
        tip = "Monitor crops regularly for climate impacts."

    return jsonify({'weather': weather, 'temperature': temp, 'tip': tip})

@app.route('/weather/history', methods=['GET'])
def weather_history():
    city = request.args.get('city')
    days = int(request.args.get('days', 3))
    today = datetime.utcnow()
    # Simulate fake data or use a real weather API with history endpoint.
    history = []
    for i in range(days):
        date = (today - timedelta(days=i)).strftime("%Y-%m-%d")
        # Fake values for example
        temp = round(25 + random.uniform(-5, 5), 1)
        desc = random.choice(["clear sky", "patchy rain", "overcast", "sunny", "moderate rain"])
        history.append({'date': date, 'weather': desc, 'temperature': temp})
    return jsonify({'city': city, 'history': history})

@app.route('/crop_advice', methods=['POST'])
def crop_advice():
    data = request.json
    soil = data.get('soil', '').lower()
    season = data.get('season', '').lower()
    region = data.get('region', '').lower()

    advice = "Maize"
    if soil == 'loamy' and season == 'kharif':
        advice = "Paddy"
    elif soil == 'black' and season == 'rabi':
        advice = "Wheat"
    elif soil == 'red' and season == 'rabi':
        advice = "Chickpea"
    elif soil == 'alluvial' and season == 'kharif':
        advice = "Sugarcane"
    elif soil == 'laterite' and season == 'summer':
        advice = "Groundnut"
    elif region in ['punjab', 'haryana'] and season == 'rabi':
        advice = "Wheat"
    elif region in ['maharashtra', 'gujarat'] and soil == 'black':
        advice = "Cotton"
    # Add more rules as needed

    # Add advisory message
    message = f"For {soil} soil in {season} season at {region.title()}, recommended crop is {advice}."
    return jsonify({'recommended_crop': advice, 'message': message})

@app.route('/fertilizer_advice', methods=['POST'])
def fertilizer_advice():
    data = request.json
    crop = data.get('crop', '').lower()
    soil = data.get('soil', '').lower()

    # Example recommendations
    recommendations = {
        ('paddy', 'loamy'): "Urea: 100kg/acre, DAP: 50kg/acre.",
        ('wheat', 'black'): "Urea: 90kg/acre, Potash: 40kg/acre.",
        ('maize', 'red'): "Nitrogen: 80kg/acre, Phosphorus: 30kg/acre.",
        ('sugarcane', 'alluvial'): "NPK: 80:40:40 kg/acre.",
    }
    response = recommendations.get((crop, soil), "Apply local balanced NPK fertilizer as per soil test.")
    return jsonify({'fertilizer_advice': response})

@app.route('/market_price', methods=['GET'])
def market_price():
    crop = request.args.get('crop', '').capitalize()
    # Simulate fluctuation
    base_prices = {
        'Paddy': 1800,
        'Wheat': 2100,
        'Maize': 1600,
        'Chickpea': 5200,
        'Cotton': 6000,
        'Sugarcane': 300,
        'Groundnut': 5400,
    }
    base = base_prices.get(crop, 1500)
    # Simulate 5% variability
    price = int(base * (1 + random.uniform(-0.05, 0.05)))
    return jsonify({'price': f"₹{price}/quintal"})

# Error handling for invalid endpoints
@app.errorhandler(404)
def page_not_found(e):
    return jsonify({'error': 'Endpoint not found'}), 404

if __name__ == '__main__':
    app.run(debug=True)
